package sa.com.neoleap.Movie.Web.Application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieWebApplication {

	public static void main(String[] args) {

		SpringApplication.run(MovieWebApplication.class, args);
	}

}
